const hamberger = document.querySelector('.hamburger')
const times = document.querySelector('.times')
const mobileNav = document.querySelector('.mobile-nav')

hamberger.onclick = () => {
    mobileNav.classList.add('open')
}

times.onclick = () => {
    mobileNav.classList.remove('open')
}





    
    





