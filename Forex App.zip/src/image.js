const { v4: uuidv4 } = require('uuid');

const images = [
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot1.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot2.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot3.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot4.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot5.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot6.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot7.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot8.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot9.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot10.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot11.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot12.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot13.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot14.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot15.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot16.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot17.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot18.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot19.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot20.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot21.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot22.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot23.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot24.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot25.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot26.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot27.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot28.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot29.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot30.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot31.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot32.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot33.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot34.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot35.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot36.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot37.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot38.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot39.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot40.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot41.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot42.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot43.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot44.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot45.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot46.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot47.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot48.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot49.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot50.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot51.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot52.jpeg",
    },
    {
        uuid : uuidv4(),
        url : "/img/ss/srcshot53.jpeg",
    },


]


module.exports = images